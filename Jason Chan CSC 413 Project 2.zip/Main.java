/*  Jason Chan
 *  918229408
 *  CSC 413-01
 *  Project 2
 */

public class Main {
    public static void main(String[] args) {
        new MenuUI();
    }
}
